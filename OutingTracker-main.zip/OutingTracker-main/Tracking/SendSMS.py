from twilio.rest import Client

def sendSMS(PhoneNum, Msg) :
    account_sid = "AC13b751c83800b2269311ba1273a37459"
    auth_token = "9df30a0aba098c1e07db6c9c102da71c"

    client = Client(account_sid, auth_token)
    PhoneNum = "+91" + PhoneNum
    message = client.messages.create(body=Msg, from_="+13123135186", to=[PhoneNum])
    print(message.sid)